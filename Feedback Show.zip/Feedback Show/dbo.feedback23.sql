﻿CREATE TABLE [dbo].[feedback23] (
    [Name]       VARCHAR (50) NOT NULL,
    [Email]      VARCHAR (50) NULL,
    [Phoneno]    VARCHAR (50) NULL,
    [Suggestion] VARCHAR (50) NULL,
    CONSTRAINT [PK_feedback23] PRIMARY KEY CLUSTERED ([Name] ASC)
);

